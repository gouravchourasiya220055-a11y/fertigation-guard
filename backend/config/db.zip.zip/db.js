import mongoose from 'mongoose';
import logger from '../utils/logger.js';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI);
    logger.info(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    logger.error(`Error connecting to MongoDB: ${error.message}`);
    // Do not exit process if we want the server to stay alive for explicit health checks
    // process.exit(1); 
  }
};

mongoose.connection.on('error', err => {
  logger.error(`MongoDB connection error: ${err}`);
});

export default connectDB;
